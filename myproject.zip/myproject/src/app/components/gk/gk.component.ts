import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gk',
  templateUrl: './gk.component.html',
  styleUrls: ['./gk.component.scss']
})
export class GkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

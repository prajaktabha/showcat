import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mcqbt',
  templateUrl: './mcqbt.component.html',
  styleUrls: ['./mcqbt.component.scss']
})
export class McqbtComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

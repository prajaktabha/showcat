import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lt',
  templateUrl: './lt.component.html',
  styleUrls: ['./lt.component.scss']
})
export class LtComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

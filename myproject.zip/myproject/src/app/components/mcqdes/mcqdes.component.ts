import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mcqdes',
  templateUrl: './mcqdes.component.html',
  styleUrls: ['./mcqdes.component.scss']
})
export class McqdesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

export class Tutorial {
    id?: any;
    quizname?: string;
    time?: string;
    count?: any;
    categoryid?: any;
  }